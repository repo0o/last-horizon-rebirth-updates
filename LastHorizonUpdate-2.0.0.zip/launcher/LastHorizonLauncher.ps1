param([switch]$Installed)

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Drawing, System.Windows.Forms

$ErrorActionPreference = 'Stop'
$AppName = 'Last Horizon: Rebirth'
$ServerAddress = '81.16.177.251:25582'
$DiscordUrl = 'https://discord.gg/47YjgDGfjg'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$DataRoot = Join-Path $env:APPDATA 'LastHorizonRebirth'
$PrismRoot = Join-Path $DataRoot 'Prism'
$PrismExe = Join-Path $PrismRoot 'prismlauncher.exe'
$InstanceId = 'Last-Horizon-Rebirth'
$InstanceRoot = Join-Path (Join-Path $PrismRoot 'instances') $InstanceId
$DefaultGameDir = Join-Path $InstanceRoot 'minecraft'
$GameDir = $DefaultGameDir
$SettingsFile = Join-Path $DataRoot 'launcher-settings.json'
$PayloadDir = Join-Path $Root 'payload'
$PayloadManifest = Join-Path $Root 'pack-manifest.json'
$InstalledManifest = Join-Path $DataRoot 'installed-manifest.json'
$BundledShaders = Join-Path $Root 'shaderpacks'
$TLauncherPackName = 'Last Horizon Rebirth'
$TLauncherTemplate = Join-Path $Root 'tlauncher-template.zip'
$LauncherVersion = '2.0'
$BundledPackVersion = '1.0.0'
$UpdateChannelFile = Join-Path $Root 'update-channel.json'
$CloudCacheRoot = Join-Path $DataRoot 'cloud-updates'

New-Item -ItemType Directory -Force -Path $DataRoot, $GameDir | Out-Null
. (Join-Path $Root 'CloudUpdater.ps1')

function Load-Settings {
    $defaults = [ordered]@{
        ramGb = 6
        shader = 'Disabled (best performance)'
        preset = 'Balanced (recommended)'
        microsoftRamGb = 6
        microsoftShader = 'Disabled (best performance)'
        microsoftPreset = 'Balanced (recommended)'
        tlauncherShader = 'Disabled (best performance)'
        tlauncherPreset = 'Balanced (recommended)'
        gameDir = $DefaultGameDir
        tlauncherPath = ''
        tlauncherGameDir = (Join-Path $env:APPDATA '.minecraft')
        tlauncherFolderManual = $false
        settingsTarget = 'Microsoft'
    }
    if (Test-Path $SettingsFile) {
        try {
            $saved = Get-Content $SettingsFile -Raw | ConvertFrom-Json
            foreach ($name in $defaults.Keys) {
                if ($null -ne $saved.$name) { $defaults[$name] = $saved.$name }
            }
        } catch { }
    }
    return [pscustomobject]$defaults
}

function Save-Settings($settings) {
    $settings | ConvertTo-Json | Set-Content -Encoding UTF8 $SettingsFile
}

function Find-TLauncher {
    $candidates = @(
        $Settings.tlauncherPath,
        (Join-Path $env:APPDATA '.minecraft\TLauncher.exe'),
        (Join-Path $env:APPDATA '.minecraft\tlauncher.exe'),
        (Join-Path $env:APPDATA '.tlauncher\TLauncher.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\TLauncher\TLauncher.exe'),
        (Join-Path $env:ProgramFiles 'TLauncher\TLauncher.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'TLauncher\TLauncher.exe'),
        (Join-Path $env:USERPROFILE 'Downloads\TLauncher.exe'),
        (Join-Path $env:USERPROFILE 'Desktop\TLauncher.exe'),
        (Join-Path $env:USERPROFILE 'Downloads\TLauncher.jar'),
        (Join-Path $env:USERPROFILE 'Desktop\TLauncher.jar')
    )
    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path $candidate)) { return $candidate }
    }
    foreach ($shortcutRoot in @([Environment]::GetFolderPath('Desktop'), (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'))) {
        if ($shortcutRoot -and (Test-Path $shortcutRoot)) {
            $shortcut = Get-ChildItem $shortcutRoot -Filter '*.lnk' -Recurse -ErrorAction SilentlyContinue |
                Where-Object { $_.BaseName -match '(?i)tlauncher' } | Select-Object -First 1
            if ($shortcut) { return $shortcut.FullName }
        }
    }
    return $null
}

function Select-TLauncher {
    $path = Find-TLauncher
    if ($path) { return $path }
    $dialog = New-Object Microsoft.Win32.OpenFileDialog
    $dialog.Title = 'Select TLauncher.exe or TLauncher.jar'
    $dialog.Filter = 'TLauncher (*.exe;*.jar;*.lnk)|*.exe;*.jar;*.lnk|All files (*.*)|*.*'
    if ($dialog.ShowDialog()) { return $dialog.FileName }
    return $null
}

function Start-TLauncher([string]$path) {
    if (!$path -or !(Test-Path $path)) { throw 'TLauncher was not found. Select TLauncher.exe when asked.' }
    if ([IO.Path]::GetExtension($path) -ieq '.jar') {
        $java = Get-Command javaw.exe, java.exe -ErrorAction SilentlyContinue | Select-Object -First 1
        if (!$java) { throw 'Java was not found. Select TLauncher.exe instead of the JAR file.' }
        Start-Process -FilePath $java.Source -ArgumentList ('-jar "{0}"' -f $path)
    } else {
        Start-Process -FilePath $path
    }
}

function Get-TLauncherGameDir {
    $configured = [string]$Settings.tlauncherGameDir
    $default = Join-Path $env:APPDATA '.minecraft'
    if ($Settings.tlauncherFolderManual -and $configured) { return $configured }
    if ($configured -and $configured -ne $default) { return $configured }
    $properties = Join-Path $env:APPDATA '.tlauncher\tlauncher-2.0.properties'
    if (Test-Path $properties) {
        $line = Get-Content -LiteralPath $properties | Where-Object { $_ -match '^minecraft\.gamedir\s*=' } | Select-Object -Last 1
        if ($line) {
            $value = ($line -replace '^minecraft\.gamedir\s*=\s*', '').Trim()
            # Java properties may escape backslashes; do not execute or expand this value.
            $value = $value.Replace('\\', '\')
            if ([IO.Path]::IsPathRooted($value) -and (Test-Path $value)) { return $value }
        }
    }
    return $default
}

function Test-TLauncherNeoForge([string]$target) {
    $versions = Join-Path $target 'versions'
    if (!(Test-Path $versions)) { return $false }
    return @(
        Get-ChildItem -LiteralPath $versions -Directory -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match '(?i)neoforge.*21\.1\.259' -and (Get-ChildItem -LiteralPath $_.FullName -Filter '*.json' -File -ErrorAction SilentlyContinue) }
    ).Count -gt 0
}

function Find-Java21 {
    $candidates = @(Get-Command java.exe -ErrorAction SilentlyContinue | ForEach-Object { $_.Source })
    foreach ($root in @((Join-Path $env:APPDATA '.tlauncher\jvms'), (Join-Path $env:APPDATA '.minecraft\runtime'))) {
        if (Test-Path $root) {
            $candidates += @(Get-ChildItem -LiteralPath $root -Filter 'java.exe' -File -Recurse -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName })
        }
    }
    foreach ($candidate in $candidates) {
        $version = (& $candidate -version 2>&1 | Out-String)
        if ($version -match 'version "21[\.\+]') { return $candidate }
    }
    return $null
}

function Ensure-TLauncherNeoForge([string]$target) {
    if (Test-TLauncherNeoForge $target) { return }
    $java = Find-Java21
    if (!$java) {
        throw 'NeoForge 21.1.259 is missing and Java 21 was not found. Install NeoForge 21.1.259 through TLauncher first, then press Play With TLauncher again.'
    }
    $base = 'https://maven.neoforged.net/releases/net/neoforged/neoforge/21.1.259/neoforge-21.1.259-installer.jar'
    $download = Join-Path $env:TEMP ('LastHorizon-NeoForge-' + [guid]::NewGuid().ToString('N') + '.jar')
    try {
        $ActionStatus.Text = 'Installing NeoForge 21.1.259 into the TLauncher game folder...'
        $Window.Dispatcher.Invoke([action]{}, 'Background')
        $expected = ((Invoke-WebRequest -Uri "$base.sha256" -UseBasicParsing).Content -split '\s+')[0]
        if ($expected -notmatch '^[a-fA-F0-9]{64}$') { throw 'NeoForge did not supply a valid SHA-256 hash.' }
        Invoke-WebRequest -Uri $base -OutFile $download -UseBasicParsing
        if ((Get-FileHash -LiteralPath $download -Algorithm SHA256).Hash -ine $expected) { throw 'NeoForge download failed its integrity check.' }
        $process = Start-Process -FilePath $java -ArgumentList ('-jar "{0}" --installClient "{1}"' -f $download, $target) -PassThru -Wait -WindowStyle Hidden
        if ($process.ExitCode -ne 0 -or !(Test-TLauncherNeoForge $target)) {
            throw 'NeoForge installation did not complete. Open TLauncher, install NeoForge 21.1.259 manually, then retry.'
        }
    } finally {
        Remove-Item -LiteralPath $download -Force -ErrorAction SilentlyContinue
    }
}

function Test-LastHorizonTLauncherProfile259([string]$target) {
    $additional = Join-Path $target 'TLauncherAdditional.json'
    $profile = Join-Path $target "$TLauncherPackName.json"
    if (!(Test-Path -LiteralPath $additional) -or !(Test-Path -LiteralPath $profile)) { return $false }
    try {
        $metadata = Get-Content -LiteralPath $additional -Raw | ConvertFrom-Json
        $profileText = Get-Content -LiteralPath $profile -Raw
        return ($metadata.modpack.name -eq $TLauncherPackName -and
                $metadata.modpack.version.gameVersionDTO.name -eq '1.21.1' -and
                $metadata.modpack.version.minecraftVersionName.name -eq '21.1.259' -and
                $profileText -match '21\.1\.259')
    } catch {
        return $false
    }
}

function Install-TLauncherPack {
    $originalGameDir = $script:GameDir
    $extract = $null
    try {
        $root = Get-TLauncherGameDir
        if (!(Test-Path $root)) { throw "TLauncher game folder was not found: $root. Choose the Directory shown in TLauncher Settings." }
        if (!(Test-Path $TLauncherTemplate)) { throw 'The TLauncher pack template is missing from this installer.' }
        Ensure-TLauncherNeoForge $root
        $target = Join-Path (Join-Path $root 'versions') $TLauncherPackName
        $extract = Join-Path $env:TEMP ('LastHorizon-TLauncher-' + [guid]::NewGuid().ToString('N'))
        Expand-Archive -LiteralPath $TLauncherTemplate -DestinationPath $extract -Force
        $templateRoot = Join-Path $extract $TLauncherPackName
        $templateInfo = Join-Path $templateRoot 'TLauncherAdditional.json'
        $templateVersion = Join-Path $templateRoot "$TLauncherPackName.json"
        if (!(Test-Path $templateInfo) -or !(Test-Path $templateVersion)) { throw 'The TLauncher template has no usable version profile.' }
        $template = Get-Content -LiteralPath $templateInfo -Raw | ConvertFrom-Json
        if ($template.modpack.name -ne $TLauncherPackName -or
            $template.modpack.version.gameVersionDTO.name -ne '1.21.1' -or
            $template.modpack.version.minecraftVersionName.name -ne '21.1.259') {
            throw 'The TLauncher template does not match the expected Minecraft and NeoForge versions.'
        }
        New-Item -ItemType Directory -Force -Path $target | Out-Null
        # The profile files are launcher-owned. Replacing them repairs missing,
        # damaged, or older TLauncher profiles without touching other versions.
        Copy-Item -LiteralPath $templateInfo -Destination $target -Force
        Copy-Item -LiteralPath $templateVersion -Destination $target -Force
        if (!(Test-LastHorizonTLauncherProfile259 $target)) {
            throw 'The Last Horizon TLauncher profile did not verify as Minecraft 1.21.1 + NeoForge 21.1.259.'
        }
        $script:GameDir = $target
        $quarantined = Repair-IsolatedPackTarget 'TLauncher'
        Copy-Pack
        # Iris is installed for every repaired TLauncher profile so players can
        # enable a recommended shader later. Shaders remain disabled unless the
        # player explicitly chooses one in the launcher.
        Ensure-Iris
        Apply-ShaderForPlay
        $modCount = @(Get-ChildItem -LiteralPath (Join-Path $target 'mods') -Filter '*.jar' -File -ErrorAction SilentlyContinue).Count
        $requiredNames = @(Get-ExpectedModNames)
        $missingNames = @($requiredNames | Where-Object { !(Test-Path -LiteralPath (Join-Path (Join-Path $target 'mods') $_)) })
        if ($missingNames.Count -gt 0) { throw "The repair is incomplete: $($missingNames.Count) required mod file(s) are missing." }
        return [pscustomobject]@{ Folder = $target; Mods = $modCount; Loader = '21.1.259'; Iris = $true; Quarantined = $quarantined }
    } finally {
        $script:GameDir = $originalGameDir
        if ($extract -and (Test-Path $extract)) { Remove-Item -LiteralPath $extract -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

function Move-LastHorizonProfileToBackup([string]$target, [string]$label) {
    if (!(Test-Path -LiteralPath $target)) { return $null }
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $backupRoot = Join-Path $DataRoot ("fresh-reinstall-backups\$stamp-$label")
    New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
    $destination = Join-Path $backupRoot ([IO.Path]::GetFileName($target))
    Move-Item -LiteralPath $target -Destination $destination -Force
    return $destination
}

function Fresh-ReinstallMicrosoft {
    if (Get-Process -Name 'prismlauncher','java','javaw' -ErrorAction SilentlyContinue) {
        throw 'Close Minecraft and the account window completely before using Fresh Reinstall.'
    }
    $backup = Move-LastHorizonProfileToBackup $InstanceRoot 'Microsoft'
    Remove-Item -LiteralPath $InstalledManifest -Force -ErrorAction SilentlyContinue
    $script:GameDir = $DefaultGameDir
    $quarantined = Install-DirectInstance
    return [pscustomobject]@{ Backup = $backup; Quarantined = $quarantined }
}

function Fresh-ReinstallTLauncher {
    if (Get-Process -Name 'TLauncher','java','javaw' -ErrorAction SilentlyContinue) {
        throw 'Close Minecraft and TLauncher completely before using Fresh Reinstall.'
    }
    $root = Get-TLauncherGameDir
    if (!(Test-Path -LiteralPath $root)) { throw "TLauncher game folder was not found: $root" }
    $target = Join-Path (Join-Path $root 'versions') $TLauncherPackName
    $backup = Move-LastHorizonProfileToBackup $target 'TLauncher'
    $installed = Install-TLauncherPack
    return [pscustomobject]@{ Backup = $backup; Installed = $installed }
}

function Get-ExpectedModNames {
    if (!(Test-Path -LiteralPath $PayloadManifest)) { return @() }
    $manifest = Get-Content -LiteralPath $PayloadManifest -Raw | ConvertFrom-Json
    @($manifest.files | Where-Object { ([string]$_.path).Replace('\','/') -match '^mods/[^/]+\.jar$' } | ForEach-Object {
        [IO.Path]::GetFileName([string]$_.path).ToLowerInvariant()
    })
}

function Repair-IsolatedPackTarget([string]$label) {
    # Last Horizon profiles are isolated game folders. Extra JARs inside this
    # specific profile can create packet/registry mismatches, so move them to a
    # recoverable backup. Never inspect or alter another TLauncher version.
    $modsDir = Join-Path $GameDir 'mods'
    New-Item -ItemType Directory -Force -Path $modsDir | Out-Null
    $expected = @{}
    foreach ($name in (Get-ExpectedModNames)) { $expected[$name] = $true }
    # Iris is launcher-managed when a shader is selected, but it is optional and
    # therefore is not part of the base payload manifest.
    $expected['iris-neoforge-1.8.14-beta.1+mc1.21.1.jar'] = $true
    $extras = @(Get-ChildItem -LiteralPath $modsDir -Filter '*.jar' -File -ErrorAction SilentlyContinue | Where-Object {
        !$expected.ContainsKey($_.Name.ToLowerInvariant())
    })
    if ($extras.Count -eq 0) { return 0 }
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $backup = Join-Path $DataRoot ("repair-backups\$stamp-$label\extra-mods")
    New-Item -ItemType Directory -Force -Path $backup | Out-Null
    foreach ($file in $extras) { Move-Item -LiteralPath $file.FullName -Destination (Join-Path $backup $file.Name) -Force }
    return $extras.Count
}

function Copy-Pack {
    if (!(Test-Path $PayloadManifest) -or !(Test-Path $PayloadDir)) {
        throw 'The final client payload is not included in this beta launcher yet.'
    }

    $manifest = Get-Content $PayloadManifest -Raw | ConvertFrom-Json
    # Never delete files from a shared Minecraft folder during repair.

    $count = [Math]::Max(1, @($manifest.files).Count)
    $i = 0
    foreach ($entry in $manifest.files) {
        $i++
        $source = Join-Path $PayloadDir $entry.path
        $target = Join-Path $GameDir $entry.path
        $targetParent = Split-Path -Parent $target
        New-Item -ItemType Directory -Force -Path $targetParent | Out-Null
        if ((Test-Path -LiteralPath $target) -and (Test-PlayerOwnedPath ([string]$entry.path))) {
            $Progress.Value = [int](100 * $i / $count)
            continue
        }
        $copy = !(Test-Path $target)
        if (!$copy) {
            $actual = (Get-FileHash -Algorithm SHA256 $target).Hash.ToLowerInvariant()
            $copy = $actual -ne $entry.sha256
        }
        if ($copy) { Copy-Item -Force $source $target }
        $Progress.Value = [int](100 * $i / $count)
        $Window.Dispatcher.Invoke([action]{}, 'Background')
    }
    if ($GameDir -eq $DefaultGameDir) { Copy-Item -Force $PayloadManifest $InstalledManifest }
    Set-Content -Encoding UTF8 (Join-Path $GameDir 'server-address.txt') $ServerAddress
    Ensure-CustomMenu
    Set-PackVersion $GameDir $BundledPackVersion
}

function Ensure-CustomMenu {
    # These are the menu's activation files, not a server resource pack setting.
    # Repair them on every launch, including older installs where FancyMenu was
    # disabled after the original pack was copied.
    foreach ($relative in @(
        'config/fancymenu/customizablemenus.txt',
        'config/fancymenu/customization/last_horizon_title.txt',
        'config/fancymenu/options.txt'
    )) {
        $source = Join-Path $PayloadDir $relative
        $destination = Join-Path $GameDir $relative
        if (!(Test-Path -LiteralPath $source)) { throw "Custom menu file is missing from the installer: $relative" }
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destination) | Out-Null
        Copy-Item -LiteralPath $source -Destination $destination -Force
    }
    $registration = Get-Content -LiteralPath (Join-Path $GameDir 'config/fancymenu/customizablemenus.txt') -Raw
    $layout = Get-Content -LiteralPath (Join-Path $GameDir 'config/fancymenu/customization/last_horizon_title.txt') -Raw
    $modFolder = Join-Path $GameDir 'mods'
    if ($registration -notmatch 'net\.minecraft\.client\.gui\.screens\.TitleScreen' -or
        $layout -notmatch 'identifier\s*=\s*title_screen' -or
        $layout -notmatch 'is_enabled\s*=\s*true' -or
        @((Get-ChildItem -LiteralPath $modFolder -Filter 'fancymenu*.jar' -File -ErrorAction SilentlyContinue)).Count -eq 0) {
        throw "Custom menu installation is incomplete in $GameDir. Run Install / Repair Game and launch the Last Horizon NeoForge profile."
    }
}

function Ensure-DirectLauncher {
    if (Test-Path $PrismExe) { return }
    $ActionStatus.Text = 'Downloading the direct-launch engine (first time only)...'
    $Window.Dispatcher.Invoke([action]{}, 'Background')
    New-Item -ItemType Directory -Force -Path $PrismRoot | Out-Null
    $archive = Join-Path $env:TEMP ('LastHorizon-Prism-' + [guid]::NewGuid().ToString('N') + '.zip')
    $extract = Join-Path $env:TEMP ('LastHorizon-Prism-' + [guid]::NewGuid().ToString('N'))
    $releaseApi = 'https://api.github.com/repos/PrismLauncher/PrismLauncher/releases/tags/11.1.1'
    $assetName = 'PrismLauncher-Windows-MinGW-w64-Portable-11.1.1.zip'
    try {
        $headers = @{ 'User-Agent' = 'LastHorizonRebirthLauncher/4.0' }
        $release = Invoke-RestMethod -Uri $releaseApi -Headers $headers
        $asset = @($release.assets | Where-Object { $_.name -eq $assetName })[0]
        if (!$asset -or !$asset.browser_download_url) { throw 'The verified direct-launch download was not found in the official release.' }
        Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $archive -Headers $headers -UseBasicParsing
        $expectedHash = ([string]$asset.digest) -replace '^sha256:', ''
        if (!$expectedHash) { throw 'The official release did not provide a SHA-256 digest, so the launcher stopped safely.' }
        $actualHash = (Get-FileHash -Algorithm SHA256 $archive).Hash
        if ($actualHash -ine $expectedHash) { throw 'The direct-launch download failed its security check and was not installed.' }
        Expand-Archive -LiteralPath $archive -DestinationPath $extract -Force
        $downloadedExe = Get-ChildItem $extract -Filter 'prismlauncher.exe' -Recurse | Select-Object -First 1
        if (!$downloadedExe) { throw 'The direct-launch engine download did not contain prismlauncher.exe.' }
        Get-ChildItem -Force $downloadedExe.Directory.FullName | ForEach-Object {
            Copy-Item $_.FullName -Destination $PrismRoot -Recurse -Force
        }
        New-Item -ItemType File -Force -Path (Join-Path $PrismRoot 'portable.txt') | Out-Null
    } finally {
        Remove-Item $archive -Force -ErrorAction SilentlyContinue
        Remove-Item $extract -Recurse -Force -ErrorAction SilentlyContinue
    }
    if (!(Test-Path $PrismExe)) { throw 'Direct-launch installation did not finish. Check the internet connection and try Repair again.' }
}

function Write-InstanceConfig {
    New-Item -ItemType Directory -Force -Path $InstanceRoot, $GameDir | Out-Null
    $ramMb = [int]$RamSlider.Value * 1024
    @"
[General]
ConfigVersion=1.3
InstanceType=OneSix
name=Last Horizon Rebirth
iconKey=last-horizon-rebirth
OverrideMemory=true
MinMemAlloc=$ramMb
MaxMemAlloc=$ramMb
OverrideMiscellaneous=true
CloseAfterLaunch=true
QuitAfterGameStop=true
JoinServerOnLaunch=false
"@ | Set-Content -Encoding UTF8 (Join-Path $InstanceRoot 'instance.cfg')
    @'
{
  "formatVersion": 1,
  "components": [
    { "uid": "net.minecraft", "version": "1.21.1", "important": true },
    { "uid": "net.neoforged", "version": "21.1.259" }
  ]
}
'@ | Set-Content -Encoding UTF8 (Join-Path $InstanceRoot 'mmc-pack.json')
    New-Item -ItemType Directory -Force -Path (Join-Path $PrismRoot 'icons') | Out-Null
    $icon = Join-Path $Root 'assets\launcher.ico'
    if (Test-Path $icon) { Copy-Item -Force $icon (Join-Path (Join-Path $PrismRoot 'icons') 'last-horizon-rebirth.ico') -ErrorAction SilentlyContinue }
}

function Install-DirectInstance {
    Ensure-DirectLauncher
    Write-InstanceConfig
    $quarantined = Repair-IsolatedPackTarget 'Microsoft'
    Copy-Pack
    Apply-ShaderForPlay
    return $quarantined
}

function Start-DirectGame {
    Ensure-DirectLauncher
    Write-InstanceConfig
    if (!(Test-Path -LiteralPath $InstalledManifest)) { Copy-Pack }
    $args = '-d "{0}" --launch "{1}"' -f $PrismRoot, $InstanceId
    Start-Process -FilePath $PrismExe -ArgumentList $args
}

function Set-IrisProperty([System.Collections.Generic.List[string]]$lines, [string]$name, [string]$value) {
    $found = $false
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match ('^' + [regex]::Escape($name) + '=')) {
            $lines[$i] = "$name=$value"
            $found = $true
        }
    }
    if (!$found) { $lines.Add("$name=$value") }
}

function Set-OptionLine([System.Collections.Generic.List[string]]$lines, [string]$name, [string]$value) {
    $found = $false
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match ('^' + [regex]::Escape($name) + ':')) {
            $lines[$i] = "${name}:$value"
            $found = $true
        }
    }
    if (!$found) { $lines.Add("${name}:$value") }
}

function Get-ModrinthFile([string]$project, [string]$loader) {
    $encodedLoaders = [Uri]::EscapeDataString('["' + $loader + '"]')
    $encodedVersions = [Uri]::EscapeDataString('["1.21.1"]')
    $uri = "https://api.modrinth.com/v2/project/$project/version?loaders=$encodedLoaders&game_versions=$encodedVersions"
    $versions = @(Invoke-RestMethod -Uri $uri -Headers @{ 'User-Agent' = 'LastHorizonRebirthLauncher/0.3' })
    if ($versions.Count -eq 0) { throw "No compatible 1.21.1 $loader download was found for $project." }
    $file = @($versions[0].files | Where-Object { $_.primary })[0]
    if (!$file) { $file = @($versions[0].files)[0] }
    return $file
}

function Ensure-Iris {
    $modsDir = Join-Path $GameDir 'mods'
    New-Item -ItemType Directory -Force -Path $modsDir | Out-Null
    $compatibleName = 'iris-neoforge-1.8.14-beta.1+mc1.21.1.jar'
    $existing = @(Get-ChildItem $modsDir -Filter '*iris*.jar' -ErrorAction SilentlyContinue)
    if (@($existing | Where-Object { $_.Name -match '(?i)1\.8\.14.beta\.1' }).Count -gt 0) { return }
    if ($existing.Count -gt 0) { throw 'An older Iris file is present in the game folder. Move it out of mods before enabling a shader.' }

    $version = Invoke-RestMethod -Uri 'https://api.modrinth.com/v2/version/KduFYu4t' -Headers @{ 'User-Agent' = 'LastHorizonRebirthLauncher/4.2' }
    if ($version.version_number -notmatch '^1\.8\.14-beta\.1\+1\.21\.1-neoforge$') {
        throw 'The expected Iris build was not returned. Shaders were not installed.'
    }
    $file = @($version.files | Where-Object { $_.primary })[0]
    if (!$file) { $file = @($version.files)[0] }
    if (!$file -or !$file.hashes.sha512) { throw 'Iris download has no integrity hash. Shaders were not installed.' }
    $target = Join-Path $modsDir $compatibleName
    Invoke-WebRequest -Uri $file.url -OutFile $target -UseBasicParsing
    $actual = (Get-FileHash -Algorithm SHA512 $target).Hash
    if ($actual -ine $file.hashes.sha512) {
        Remove-Item -LiteralPath $target -Force
        throw 'Iris download failed its integrity check. Shaders were not installed.'
    }
}

function Install-ModrinthShader([string]$project) {
    $shaderDir = Join-Path $GameDir 'shaderpacks'
    New-Item -ItemType Directory -Force -Path $shaderDir | Out-Null
    $file = Get-ModrinthFile $project 'iris'
    $target = Join-Path $shaderDir $file.filename
    if (!(Test-Path $target)) {
        $ActionStatus.Text = "Downloading $([string]$ShaderBox.SelectedItem) from its official project..."
        $Window.Dispatcher.Invoke([action]{}, 'Background')
        Invoke-WebRequest -Uri $file.url -OutFile $target -UseBasicParsing
    }
    return $file.filename
}

function Install-EmanruxShader {
    $shaderDir = Join-Path $GameDir 'shaderpacks'
    $target = Join-Path $shaderDir 'Emanrux'
    if (Test-Path (Join-Path $target 'shaders')) { return 'Emanrux' }
    New-Item -ItemType Directory -Force -Path $shaderDir | Out-Null
    $tempRoot = Join-Path $env:TEMP ('LastHorizon-Emanrux-' + [guid]::NewGuid().ToString('N'))
    $archive = "$tempRoot.zip"
    try {
        Invoke-WebRequest -Uri 'https://github.com/Emanrux-dev/Emanrux-Shader/archive/refs/heads/Beta.zip' -OutFile $archive -UseBasicParsing
        Expand-Archive -Path $archive -DestinationPath $tempRoot -Force
        $shaders = Get-ChildItem $tempRoot -Directory -Recurse | Where-Object { $_.Name -eq 'shaders' } | Select-Object -First 1
        if (!$shaders) { throw 'The official Emanrux archive did not contain a shaders folder.' }
        $packRoot = Split-Path -Parent $shaders.FullName
        Copy-Item $packRoot -Destination $target -Recurse -Force
    } finally {
        Remove-Item $archive -Force -ErrorAction SilentlyContinue
        Remove-Item $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
    return 'Emanrux'
}

function Apply-PerformancePreset {
    $choice = [string]$PresetBox.SelectedItem
    $values = switch -Wildcard ($choice) {
        'Best Performance*' { @{ renderDistance='8'; simulationDistance='5'; entityDistanceScaling='0.75'; particles='decreased'; mipmapLevels='2'; biomeBlendRadius='0'; maxFps='120'; enableVsync='false' } }
        'Quality*'          { @{ renderDistance='16'; simulationDistance='10'; entityDistanceScaling='1.25'; particles='all'; mipmapLevels='4'; biomeBlendRadius='5'; maxFps='144'; enableVsync='false' } }
        'Cinematic*'        { @{ renderDistance='20'; simulationDistance='10'; entityDistanceScaling='1.5'; particles='all'; mipmapLevels='4'; biomeBlendRadius='7'; maxFps='60'; enableVsync='true' } }
        default             { @{ renderDistance='12'; simulationDistance='8'; entityDistanceScaling='1.0'; particles='all'; mipmapLevels='4'; biomeBlendRadius='2'; maxFps='120'; enableVsync='false' } }
    }
    $optionsFile = Join-Path $GameDir 'options.txt'
    $lines = New-Object 'System.Collections.Generic.List[string]'
    if (Test-Path $optionsFile) { foreach ($line in (Get-Content $optionsFile)) { $lines.Add([string]$line) } }
    foreach ($name in $values.Keys) { Set-OptionLine $lines $name $values[$name] }
    $lines | Set-Content -Encoding UTF8 $optionsFile
    $Settings.preset = $choice
}

function Apply-ShaderSelection {
    $choice = [string]$ShaderBox.SelectedItem
    $shaderDir = Join-Path $GameDir 'shaderpacks'
    $configDir = Join-Path $GameDir 'config'
    $irisFile = Join-Path $configDir 'iris.properties'
    New-Item -ItemType Directory -Force -Path $shaderDir, $configDir | Out-Null

    $lines = New-Object 'System.Collections.Generic.List[string]'
    if (Test-Path $irisFile) {
        foreach ($line in (Get-Content $irisFile)) { $lines.Add([string]$line) }
    }

    if ($choice -eq 'Photon') {
        $source = Join-Path $BundledShaders 'photon_v1.3b.zip'
        if (!(Test-Path $source)) { throw 'The bundled Photon shader file is missing.' }
        Copy-Item -Force $source (Join-Path $shaderDir 'photon_v1.3b.zip')
        $shaderFile = 'photon_v1.3b.zip'
    } elseif ($choice -eq 'Fantasy') {
        $shaderFile = Install-ModrinthShader 'fantasy-shaders'
    } elseif ($choice -eq 'Eclipse') {
        $shaderFile = Install-ModrinthShader 'eclipseshaders'
    } elseif ($choice -eq 'Solas') {
        $shaderFile = Install-ModrinthShader 'solas-shader'
    } elseif ($choice -eq 'Emanrux') {
        $shaderFile = Install-EmanruxShader
    } elseif ($choice -eq 'Amethyst') {
        $shaderFile = Install-ModrinthShader 'amethyst-shaders'
    } elseif ($choice -eq 'Hysteria') {
        $shaderFile = Install-ModrinthShader 'hysteria-shaders'
    } elseif ($choice -eq 'IterationT') {
        $existing = @(Get-ChildItem $shaderDir -File | Where-Object { $_.Name -match '(?i)iteration.?t' } | Select-Object -First 1)
        if ($existing.Count -eq 0) {
            Start-Process 'https://rutherin.netlify.app/'
            throw 'IterationT has no safe automatic official download. Its author page was opened; download the ZIP into the shaderpacks folder, then press Apply again.'
        }
        $shaderFile = $existing[0].Name
    } else {
        Set-IrisProperty $lines 'enableShaders' 'false'
    }

    if ($choice -ne 'Disabled (best performance)') {
        Ensure-Iris
        Set-IrisProperty $lines 'shaderPack' $shaderFile
        Set-IrisProperty $lines 'enableShaders' 'true'
        $shadowDistance = switch -Wildcard ([string]$PresetBox.SelectedItem) {
            'Best Performance*' { '8' }
            'Quality*' { '24' }
            'Cinematic*' { '32' }
            default { '16' }
        }
        Set-IrisProperty $lines 'maxShadowRenderDistance' $shadowDistance
    }

    $lines | Set-Content -Encoding UTF8 $irisFile
    Apply-PerformancePreset
    $Settings.shader = $choice
    Save-Settings $Settings
}

function Apply-ShaderForPlay {
    try { Apply-ShaderSelection }
    catch {
        if ([string]$ShaderBox.SelectedItem -eq 'Disabled (best performance)') { throw }
        $reason = $_.Exception.Message
        $ShaderBox.SelectedItem = 'Disabled (best performance)'
        Apply-ShaderSelection
        [System.Windows.MessageBox]::Show("The optional shader could not be enabled: $reason`n`nMinecraft will continue without shaders.", $AppName, 'OK', 'Warning') | Out-Null
    }
}

$Settings = Load-Settings
$GameDir = $DefaultGameDir
$Settings.gameDir = $GameDir
New-Item -ItemType Directory -Force -Path $GameDir | Out-Null

[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Last Horizon: Rebirth Launcher" Width="1050" Height="750"
        MinWidth="760" MinHeight="610" WindowStartupLocation="CenterScreen"
        Background="#090B0E" FontFamily="Segoe UI" Foreground="#F5E6C8">
  <Window.Resources>
    <Style TargetType="Button">
      <Setter Property="Foreground" Value="#FFF4DE"/><Setter Property="Background" Value="#8F3D1D"/>
      <Setter Property="BorderBrush" Value="#E19A49"/><Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding" Value="16,10"/><Setter Property="Margin" Value="0,6,0,0"/>
      <Setter Property="FontWeight" Value="SemiBold"/><Setter Property="Cursor" Value="Hand"/>
    </Style>
    <Style TargetType="RadioButton"><Setter Property="Foreground" Value="#FFF4DE"/><Setter Property="Margin" Value="0,6,16,6"/></Style>
    <Style TargetType="TextBox"><Setter Property="Background" Value="#15191D"/><Setter Property="Foreground" Value="#F5E6C8"/><Setter Property="BorderBrush" Value="#73563A"/><Setter Property="Padding" Value="8"/></Style>
    <Style TargetType="ComboBox"><Setter Property="Background" Value="#F4EBDD"/><Setter Property="Foreground" Value="#17120D"/><Setter Property="BorderBrush" Value="#E19A49"/><Setter Property="Padding" Value="8,5"/></Style>
    <Style TargetType="ComboBoxItem"><Setter Property="Background" Value="#F4EBDD"/><Setter Property="Foreground" Value="#17120D"/><Setter Property="Padding" Value="8,5"/></Style>
  </Window.Resources>
  <Grid>
    <Image x:Name="BackgroundImage" Stretch="UniformToFill" Opacity="0.48"/>
    <Rectangle Fill="#A6080A0D"/>
    <Grid Margin="48,36">
      <Grid.ColumnDefinitions><ColumnDefinition Width="1.1*"/><ColumnDefinition Width="420"/></Grid.ColumnDefinitions>
      <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
      <StackPanel Grid.Column="0" Grid.Row="0" Margin="0,0,42,0">
        <Image x:Name="LogoImage" Height="155" HorizontalAlignment="Left" Stretch="Uniform"/>
        <TextBlock Text="THE OLD WORLD ENDED. YOURS BEGINS HERE." Foreground="#E6A85C" FontSize="15" FontWeight="Bold" Margin="4,10,0,0"/>
      </StackPanel>
      <StackPanel Grid.Column="0" Grid.Row="1" VerticalAlignment="Bottom" Margin="4,0,55,20">
        <TextBlock Text="Fifteen years after the fall, the bunker doors are opening." FontSize="21" FontWeight="Light" TextWrapping="Wrap"/>
        <TextBlock Text="Ride beyond the frontier. Recover the blueprints. Rebuild what was lost." Foreground="#C9B89E" FontSize="15" TextWrapping="Wrap" Margin="0,10,0,0"/>
        <Border Background="#B516191C" BorderBrush="#67523E" BorderThickness="1" Padding="12" Margin="0,22,0,0">
          <StackPanel Orientation="Horizontal"><Ellipse x:Name="ServerDot" Width="10" Height="10" Fill="#D8A03E" Margin="0,3,9,0"/><TextBlock x:Name="ServerStatus" Text="Checking server..." Foreground="#F5E6C8"/><TextBlock Text="  |  81.16.177.251:25582" Foreground="#C9B89E"/></StackPanel>
        </Border>
      </StackPanel>
      <Border Grid.Column="1" Grid.RowSpan="3" Background="#E5101215" BorderBrush="#705238" BorderThickness="1" Padding="20">
       <ScrollViewer VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Disabled"><StackPanel>
          <TextBlock x:Name="ModeHeading" Text="LAUNCH CONTROL" FontSize="20" FontWeight="Bold" Foreground="#F0B667"/>
          <TextBlock Text="The two launch methods use separate Minecraft folders and setup steps." Foreground="#AFA397" TextWrapping="Wrap" Margin="0,5,0,12"/>
          <Border Background="#9820272D" BorderBrush="#4D7987" BorderThickness="1" Padding="11" Margin="0,0,0,4">
            <StackPanel><TextBlock Text="PLAY" Foreground="#5ED6E8" FontWeight="Bold"/><TextBlock Text="The game opens at the custom Minecraft main menu. Join the server from there when ready." Foreground="#D8CBB7" FontSize="12" TextWrapping="Wrap" Margin="0,4,0,0"/></StackPanel>
          </Border>
          <StackPanel x:Name="MicrosoftRamControls"><TextBlock Text="Memory" Foreground="#C9B89E" Margin="0,18,0,5"/><StackPanel Orientation="Horizontal"><Slider x:Name="RamSlider" Minimum="4" Maximum="16" TickFrequency="1" IsSnapToTickEnabled="True" Width="265"/><TextBlock x:Name="RamLabel" Margin="12,1,0,0" FontWeight="Bold"/></StackPanel></StackPanel>
          <TextBlock x:Name="TLauncherMemoryNote" Visibility="Collapsed" Text="Set memory in TLauncher Settings; this launcher does not change TLauncher's RAM allocation." Foreground="#C9B89E" TextWrapping="Wrap" Margin="0,16,0,0"/>
          <TextBlock Text="Optional shader" Foreground="#C9B89E" Margin="0,14,0,5"/>
          <Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><ComboBox x:Name="ShaderBox"/><Button x:Name="ApplyShaderButton" Grid.Column="1" Content="Apply" Margin="8,0,0,0" Padding="13,7"/></Grid>
          <TextBlock Text="Iris is installed automatically. Disabled turns shaders off but keeps Iris ready." Foreground="#81796F" FontSize="11" Margin="0,5,0,0"/>
          <TextBlock Text="Graphics preset" Foreground="#C9B89E" Margin="0,12,0,5"/>
          <ComboBox x:Name="PresetBox"/>
          <TextBox x:Name="GameFolder" Visibility="Collapsed" IsReadOnly="True"/>
          <ProgressBar x:Name="Progress" Height="6" Minimum="0" Maximum="100" Margin="0,16,0,4" Foreground="#C46A2E" Background="#28231E"/>
          <TextBlock x:Name="ActionStatus" Text="Launcher ready" Foreground="#B8A992" FontSize="12"/>
          <StackPanel x:Name="MicrosoftControls" Visibility="Collapsed">
          <Button x:Name="PlayButton" Content="PLAY MINECRAFT" FontSize="16" Padding="14,12" Margin="0,13,0,0" Background="#A74720"/>
          <Expander Header="MICROSOFT SETUP / REPAIR" Foreground="#F5E6C8" Margin="0,10,0,0">
            <StackPanel>
              <TextBlock Text="This installs a separate Minecraft 1.21.1 + NeoForge 21.1.259 game instance. Sign in with your Microsoft Minecraft account once." TextWrapping="Wrap" Foreground="#C9B89E" Margin="0,5"/>
              <Button x:Name="InstallButton" Content="INSTALL / REPAIR GAME"/>
              <Button x:Name="AccountButton" Content="MICROSOFT ACCOUNT / SIGN IN" Background="#304A59" BorderBrush="#65A5C1"/>
            </StackPanel>
          </Expander>
          </StackPanel>
          <StackPanel x:Name="TLauncherControls" Visibility="Collapsed">
            <TextBlock Text="Creates the named Last Horizon Rebirth pack under TLauncher's versions folder. Both launcher paths are pinned to NeoForge 21.1.259 for Accessories and owo-lib compatibility." TextWrapping="Wrap" Foreground="#C9B89E" Margin="0,13,0,0"/>
            <Button x:Name="TLauncherButton" Content="INSTALL PACK AND OPEN TLAUNCHER" FontSize="15" Padding="14,12" Margin="0,12,0,0" Background="#31543A" BorderBrush="#6DA778"/>
            <Expander Header="TLAUNCHER SETUP" Foreground="#F5E6C8" Margin="0,10,0,0">
              <StackPanel><TextBlock Text="If TLauncher uses a different game directory, choose exactly the Directory shown in its settings." TextWrapping="Wrap" Foreground="#C9B89E" Margin="0,5"/><Button x:Name="TLauncherFolderButton" Content="CHANGE TLAUNCHER GAME FOLDER" Background="#272C33" BorderBrush="#626C78" Padding="12,7"/></StackPanel>
            </Expander>
          </StackPanel>
          <Button x:Name="SwitchModeButton" Content="CHANGE LAUNCH METHOD" Background="#272C33" BorderBrush="#626C78" Margin="0,12,0,0"/>
          <Button x:Name="DiscordButton" Content="OPEN DISCORD" Background="#272C33" BorderBrush="#626C78"/>
          <TextBlock Text="Microsoft passwords remain with Microsoft's sign-in page; this app never requests or stores them." Foreground="#81796F" FontSize="11" TextWrapping="Wrap" Margin="0,12,0,0"/>
        </StackPanel></ScrollViewer>
      </Border>
      <TextBlock Grid.Column="0" Grid.Row="2" Text="LAST HORIZON: REBIRTH  |  LAUNCHER V5 TEST BUILD" Foreground="#A89A8B" FontSize="11" Margin="4,0,0,4"/>
    </Grid>
  </Grid>
</Window>
'@

$activeXaml = [xml](Get-Content -LiteralPath (Join-Path $Root 'LauncherWindow.xaml') -Raw)
$reader = New-Object System.Xml.XmlNodeReader $activeXaml
$Window = [Windows.Markup.XamlReader]::Load($reader)
foreach ($name in @('BackgroundImage','LogoImage','ServerDot','ServerStatus','CloudStatus','CloudStatusDot','CheckUpdatesButton','UpdatesButton','ShadersButton','SettingsToggleButton','SettingsExpander','HelpButton','SettingsTargetBox','RamSlider','RamLabel','MicrosoftRamControls','TLauncherMemoryNote','ShaderBox','ApplyShaderButton','PresetBox','GameFolder','Progress','ActionStatus','ModeHeading','MicrosoftControls','TLauncherControls','SwitchModeButton','PlayButton','InstallButton','AccountButton','MicrosoftFreshButton','TLauncherPlayButton','TLauncherButton','TLauncherFolderButton','TLauncherFreshButton','DiscordButton')) {
    Set-Variable -Name $name -Value $Window.FindName($name) -Scope Script
}

$background = Join-Path $Root 'assets\background.png'
$logo = Join-Path $Root 'assets\logo.png'
if (Test-Path $background) { $BackgroundImage.Source = [Windows.Media.Imaging.BitmapImage]::new([Uri]$background) }
if (Test-Path $logo) { $LogoImage.Source = [Windows.Media.Imaging.BitmapImage]::new([Uri]$logo) }
$GameFolder.Text = $GameDir
$RamSlider.Value = [double]$Settings.ramGb
$RamLabel.Text = "$($Settings.ramGb) GB"
$SettingsTargetBox.Items.Add('Microsoft') | Out-Null
$SettingsTargetBox.Items.Add('TLauncher') | Out-Null
$SettingsTargetBox.SelectedItem = if ([string]$Settings.settingsTarget -in @('Microsoft','TLauncher')) { [string]$Settings.settingsTarget } else { 'Microsoft' }
$script:SelectedMode = [string]$SettingsTargetBox.SelectedItem
$ShaderBox.Items.Add('Disabled (best performance)') | Out-Null
foreach ($shaderName in @('Photon','Fantasy','Eclipse','Solas','IterationT','Emanrux','Amethyst','Hysteria')) { $ShaderBox.Items.Add($shaderName) | Out-Null }
if ($ShaderBox.Items -contains $Settings.shader) { $ShaderBox.SelectedItem = $Settings.shader }
else { $ShaderBox.SelectedIndex = 0 }
foreach ($presetName in @('Best Performance','Balanced (recommended)','Quality','Cinematic')) { $PresetBox.Items.Add($presetName) | Out-Null }
if ($PresetBox.Items -contains $Settings.preset) { $PresetBox.SelectedItem = $Settings.preset }
else { $PresetBox.SelectedItem = 'Balanced (recommended)' }
if ((Test-Path $InstalledManifest) -and (Test-Path $PrismExe) -and (Test-Path (Join-Path $InstanceRoot 'mmc-pack.json'))) {
    $InstallButton.Content = 'VERIFY / REPAIR GAME'
    $ActionStatus.Text = 'Direct game instance ready.'
} else {
    $InstallButton.Content = 'FIRST TIME SETUP / REPAIR'
    $ActionStatus.Text = 'First time: run Setup, then sign in once.'
}

[xml]$modeXaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Last Horizon: Rebirth - Choose Launcher" Width="850" Height="430" ResizeMode="NoResize"
        WindowStartupLocation="CenterScreen" Background="#0E1216" FontFamily="Segoe UI" Foreground="#F5E6C8">
  <Grid Margin="34">
    <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
    <TextBlock Text="LAST HORIZON: REBIRTH" FontSize="29" FontWeight="Bold" Foreground="#E6A85C" HorizontalAlignment="Center"/>
    <TextBlock Grid.Row="1" Text="Choose how you play. Each option has its own game setup." FontSize="15" Foreground="#C9B89E" HorizontalAlignment="Center" Margin="0,9,0,25"/>
    <Grid Grid.Row="2"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
      <Border Grid.Column="0" Background="#20272D" BorderBrush="#D18844" BorderThickness="2" CornerRadius="6" Margin="0,0,10,0" Padding="20">
        <StackPanel><TextBlock Text="MINECRAFT ACCOUNT" FontSize="20" FontWeight="Bold" Foreground="#F0B667"/><TextBlock Text="Sign in with Microsoft. The game launches directly into your Last Horizon Minecraft menu." TextWrapping="Wrap" Margin="0,10,0,20"/><Button x:Name="ChooseMicrosoft" Content="CHOOSE MINECRAFT" Padding="12" Background="#A74720" Foreground="White" FontWeight="Bold"/></StackPanel>
      </Border>
      <Border Grid.Column="1" Background="#1B2922" BorderBrush="#6DA778" BorderThickness="2" CornerRadius="6" Margin="10,0,0,0" Padding="20">
        <StackPanel><TextBlock Text="TLAUNCHER" FontSize="20" FontWeight="Bold" Foreground="#95D6A3"/><TextBlock Text="Install the named Last Horizon Rebirth pack in TLauncher's game folder. Finish launching inside TLauncher." TextWrapping="Wrap" Margin="0,10,0,20"/><Button x:Name="ChooseTLauncher" Content="CHOOSE TLAUNCHER" Padding="12" Background="#31543A" Foreground="White" FontWeight="Bold"/></StackPanel>
      </Border>
    </Grid>
  </Grid>
</Window>
'@

function Save-CurrentModeSettings {
    $Settings.settingsTarget = [string]$script:SelectedMode
    if ($script:SelectedMode -eq 'Microsoft') {
        $Settings.microsoftRamGb = [int]$RamSlider.Value
        $Settings.microsoftShader = [string]$ShaderBox.SelectedItem
        $Settings.microsoftPreset = [string]$PresetBox.SelectedItem
    } elseif ($script:SelectedMode -eq 'TLauncher') {
        $Settings.tlauncherShader = [string]$ShaderBox.SelectedItem
        $Settings.tlauncherPreset = [string]$PresetBox.SelectedItem
    }
    Save-Settings $Settings
}

function Set-SettingsTarget([string]$mode) {
    if ($mode -notin @('Microsoft','TLauncher')) { return }
    $script:SelectedMode = $mode
    $script:LoadingMode = $true
    try {
        $shaderChoice = if ($mode -eq 'Microsoft') { $Settings.microsoftShader } else { $Settings.tlauncherShader }
        $presetChoice = if ($mode -eq 'Microsoft') { $Settings.microsoftPreset } else { $Settings.tlauncherPreset }
        $ShaderBox.SelectedItem = if ($ShaderBox.Items -contains $shaderChoice) { $shaderChoice } else { 'Disabled (best performance)' }
        $PresetBox.SelectedItem = if ($PresetBox.Items -contains $presetChoice) { $presetChoice } else { 'Balanced (recommended)' }
        $MicrosoftRamControls.Visibility = if ($mode -eq 'Microsoft') { 'Visible' } else { 'Collapsed' }
        $TLauncherMemoryNote.Visibility = if ($mode -eq 'Microsoft') { 'Collapsed' } else { 'Visible' }
        $Settings.settingsTarget = $mode
        Save-Settings $Settings
    } finally { $script:LoadingMode = $false }
}

function Select-LaunchMode {
    Save-CurrentModeSettings
    $script:ModePicker = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $modeXaml))
    $script:ModePicker.FindName('ChooseMicrosoft').Add_Click({ $script:SelectedMode = 'Microsoft'; $script:ModePicker.DialogResult = $true })
    $script:ModePicker.FindName('ChooseTLauncher').Add_Click({ $script:SelectedMode = 'TLauncher'; $script:ModePicker.DialogResult = $true })
    if ($script:ModePicker.ShowDialog() -ne $true) { return $false }
    $script:LoadingMode = $true
    try {
        $isMicrosoft = $script:SelectedMode -eq 'Microsoft'
        $MicrosoftControls.Visibility = if ($isMicrosoft) { 'Visible' } else { 'Collapsed' }
        $TLauncherControls.Visibility = if ($isMicrosoft) { 'Collapsed' } else { 'Visible' }
        $MicrosoftRamControls.Visibility = if ($isMicrosoft) { 'Visible' } else { 'Collapsed' }
        $TLauncherMemoryNote.Visibility = if ($isMicrosoft) { 'Collapsed' } else { 'Visible' }
        $ModeHeading.Text = if ($isMicrosoft) { 'MINECRAFT ACCOUNT' } else { 'TLAUNCHER PACK' }
        $shaderChoice = if ($isMicrosoft) { $Settings.microsoftShader } else { $Settings.tlauncherShader }
        $presetChoice = if ($isMicrosoft) { $Settings.microsoftPreset } else { $Settings.tlauncherPreset }
        $RamSlider.Value = [double]$Settings.microsoftRamGb
        $ShaderBox.SelectedItem = if ($ShaderBox.Items -contains $shaderChoice) { $shaderChoice } else { 'Disabled (best performance)' }
        $PresetBox.SelectedItem = if ($PresetBox.Items -contains $presetChoice) { $presetChoice } else { 'Balanced (recommended)' }
        $ActionStatus.Text = if ($isMicrosoft) { 'Minecraft account mode ready.' } else { 'TLauncher mode: install the named pack before opening it.' }
    } finally { $script:LoadingMode = $false }
    return $true
}

function Invoke-ModeGameAction([scriptblock]$action) {
    $previous = $script:GameDir
    try {
        if ($script:SelectedMode -eq 'TLauncher') {
            $script:GameDir = Join-Path (Join-Path (Get-TLauncherGameDir) 'versions') $TLauncherPackName
            if (!(Test-Path (Join-Path $script:GameDir 'TLauncherAdditional.json'))) { throw 'Install the TLauncher pack first.' }
        }
        & $action
    } finally { $script:GameDir = $previous }
}

function Update-CloudStatusDisplay($status) {
    $CloudStatus.Text = [string]$status.Message; $ActionStatus.Text = [string]$status.Message
    $CloudStatusDot.Fill = switch ([string]$status.State) { 'Current' {'#58C47D'} 'Available' {'#E9A84D'} 'Error' {'#CF5A4B'} default {'#56C8D5'} }
}

function Invoke-CloudUpdateCheck([bool]$automatic) {
    $status=Get-CloudUpdateStatus; Update-CloudStatusDisplay $status
    if ($status.State -eq 'Available') { $Progress.Value=8; $changed=Install-CloudUpdate $status.Manifest; $Progress.Value=100; $status=Get-CloudUpdateStatus; Update-CloudStatusDisplay $status; $ActionStatus.Text="Update installed and verified • $changed file(s)" }
    elseif (!$automatic -and $status.State -eq 'Current') { [System.Windows.MessageBox]::Show('Your Last Horizon pack is up to date.',$AppName,'OK','Information')|Out-Null }
}

$RamSlider.Add_ValueChanged({ $RamLabel.Text = "$([int]$RamSlider.Value) GB" })
$SettingsTargetBox.Add_SelectionChanged({ if ($Window.IsLoaded -and !$script:LoadingMode) { Set-SettingsTarget ([string]$SettingsTargetBox.SelectedItem) } })
$ApplyShaderButton.Add_Click({
    try {
        Invoke-ModeGameAction { Apply-ShaderSelection }
        Save-CurrentModeSettings
        $ActionStatus.Text = if ($ShaderBox.SelectedItem -eq 'Disabled (best performance)') { 'Shaders disabled and performance preset applied.' } else { "$($ShaderBox.SelectedItem) enabled with the $($PresetBox.SelectedItem) preset." }
    } catch {
        $ActionStatus.Text = $_.Exception.Message
        [System.Windows.MessageBox]::Show($_.Exception.Message, $AppName, 'OK', 'Warning') | Out-Null
    }
})
$PresetBox.Add_SelectionChanged({
    if ($Window.IsLoaded -and !$script:LoadingMode) {
        try { Invoke-ModeGameAction { Apply-PerformancePreset }; Save-CurrentModeSettings; $ActionStatus.Text = "$($PresetBox.SelectedItem) settings applied." } catch { $ActionStatus.Text = $_.Exception.Message }
    }
})
$InstallButton.Add_Click({
    try {
        $script:SelectedMode = 'Microsoft'
        $ActionStatus.Text = 'Installing direct launcher, NeoForge instance, mods and settings...'
        $Progress.Value = 0
        $quarantined = Install-DirectInstance
        $Progress.Value = 100
        $ActionStatus.Text = if ($quarantined -gt 0) { "Game repaired; $quarantined conflicting mod(s) moved to a safe backup." } else { 'Game verified and ready. Sign in once, then use Play Minecraft.' }
        $InstallButton.Content = 'VERIFY / REPAIR GAME'
        Invoke-CloudUpdateCheck $true
    } catch {
        $ActionStatus.Text = $_.Exception.Message
        [System.Windows.MessageBox]::Show($_.Exception.Message, $AppName, 'OK', 'Warning') | Out-Null
    }
})
$AccountButton.Add_Click({
    try {
        $script:SelectedMode = 'Microsoft'
        Ensure-DirectLauncher
        Write-InstanceConfig
        $ActionStatus.Text = 'One-time step: Accounts > Manage Accounts > Add Microsoft, then close that window.'
        $accountArgs = '-d "{0}"' -f $PrismRoot
        Start-Process -FilePath $PrismExe -ArgumentList $accountArgs
    } catch {
        $ActionStatus.Text = $_.Exception.Message
        [System.Windows.MessageBox]::Show($_.Exception.Message, $AppName, 'OK', 'Warning') | Out-Null
    }
})
$MicrosoftFreshButton.Add_Click({
    try {
        $answer = [System.Windows.MessageBox]::Show("This will replace the complete Last Horizon Microsoft game profile, including its mods and configuration, with a clean verified copy.`n`nA recoverable backup will be created first. Your Microsoft account and unrelated Minecraft installations will not be removed.`n`nContinue?", $AppName, 'YesNo', 'Warning')
        if ($answer -ne [System.Windows.MessageBoxResult]::Yes) { return }
        $script:SelectedMode = 'Microsoft'
        $ActionStatus.Text = 'Creating backup and performing a clean Microsoft reinstall...'
        $Progress.Value = 0
        $result = Fresh-ReinstallMicrosoft
        $Progress.Value = 100
        Invoke-CloudUpdateCheck $true
        $ActionStatus.Text = 'Fresh Microsoft reinstall completed and verified.'
        [System.Windows.MessageBox]::Show("Fresh reinstall completed.`n`nA clean Last Horizon profile was installed and checked for updates.`n`nBackup: $($result.Backup)", $AppName, 'OK', 'Information') | Out-Null
    } catch {
        $ActionStatus.Text = $_.Exception.Message
        [System.Windows.MessageBox]::Show($_.Exception.Message, $AppName, 'OK', 'Warning') | Out-Null
    }
})
$TLauncherFolderButton.Add_Click({
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Choose the Minecraft game folder used by TLauncher (the folder containing mods and versions)'
    $dialog.SelectedPath = [string]$Settings.tlauncherGameDir
    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $Settings.tlauncherGameDir = $dialog.SelectedPath
        $Settings.tlauncherFolderManual = $true
        Save-Settings $Settings
        $ActionStatus.Text = "TLauncher game folder set to $($dialog.SelectedPath)"
    }
})
$TLauncherButton.Add_Click({
    try {
        $script:SelectedMode = 'TLauncher'
        $path = Select-TLauncher
        if (!$path) { throw 'TLauncher selection was cancelled.' }
        if (Get-Process -Name 'TLauncher' -ErrorAction SilentlyContinue) { throw 'Close TLauncher completely before installing the named pack, then try again.' }
        $Settings.tlauncherPath = $path
        Save-CurrentModeSettings
        $ActionStatus.Text = 'Creating the named Last Horizon Rebirth TLauncher pack...'
        $Progress.Value = 0
        $installed = Install-TLauncherPack
        $Progress.Value = 100
        $ActionStatus.Text = if ($installed.Quarantined -gt 0) { "$($installed.Mods) mods verified; $($installed.Quarantined) conflicting mod(s) backed up." } else { "$($installed.Mods) mods verified in the isolated TLauncher pack." }
        Invoke-CloudUpdateCheck $true
        [System.Windows.MessageBox]::Show("The isolated Last Horizon Rebirth profile was repaired with $($installed.Mods) mod files.`n`nVerified loader: NeoForge $($installed.Loader)`nIris: Installed and ready`n`nOther TLauncher versions, saves, screenshots, maps, keybinds and shader packs were not removed.`n`nOpen TLauncher, select Last Horizon Rebirth, and press Enter the Game.", $AppName, 'OK', 'Information') | Out-Null
    } catch {
        $ActionStatus.Text = $_.Exception.Message
        [System.Windows.MessageBox]::Show($_.Exception.Message, $AppName, 'OK', 'Information') | Out-Null
    }
})
$TLauncherFreshButton.Add_Click({
    try {
        $answer = [System.Windows.MessageBox]::Show("This will replace only the isolated Last Horizon Rebirth TLauncher profile, including its mods and configuration, with a clean verified copy.`n`nA recoverable backup will be created first. Other TLauncher versions and unrelated Minecraft folders will not be removed.`n`nContinue?", $AppName, 'YesNo', 'Warning')
        if ($answer -ne [System.Windows.MessageBoxResult]::Yes) { return }
        $script:SelectedMode = 'TLauncher'
        $path = Select-TLauncher
        if (!$path) { throw 'TLauncher selection was cancelled.' }
        $Settings.tlauncherPath = $path
        Save-Settings $Settings
        $ActionStatus.Text = 'Creating backup and performing a clean TLauncher reinstall...'
        $Progress.Value = 0
        $result = Fresh-ReinstallTLauncher
        $Progress.Value = 100
        Invoke-CloudUpdateCheck $true
        $ActionStatus.Text = 'Fresh TLauncher profile reinstall completed and verified.'
        [System.Windows.MessageBox]::Show("Fresh reinstall completed with $($result.Installed.Mods) verified mod files.`n`nVerified loader: NeoForge $($result.Installed.Loader)`nIris: Installed and ready`n`nOpen TLauncher, select Last Horizon Rebirth, and press Enter the Game.`n`nBackup: $($result.Backup)", $AppName, 'OK', 'Information') | Out-Null
    } catch {
        $ActionStatus.Text = $_.Exception.Message
        [System.Windows.MessageBox]::Show($_.Exception.Message, $AppName, 'OK', 'Warning') | Out-Null
    }
})
$TLauncherPlayButton.Add_Click({
    try {
        $script:SelectedMode='TLauncher'
        $root=Get-TLauncherGameDir
        $pack=Join-Path (Join-Path $root 'versions') $TLauncherPackName
        if (!(Test-Path (Join-Path $pack 'TLauncherAdditional.json'))) { throw 'Install / Repair the TLauncher pack first.' }
        if (!(Test-LastHorizonTLauncherProfile259 $pack)) { throw 'The TLauncher profile is not NeoForge 21.1.259. Close TLauncher and press Fresh Reinstall.' }
        Ensure-TLauncherNeoForge $root
        Invoke-CloudUpdateCheck $true
        $path=Select-TLauncher; if (!$path) { throw 'TLauncher selection was cancelled.' }
        $Settings.tlauncherPath=$path; Save-Settings $Settings; Start-TLauncher $path
        $ActionStatus.Text='TLauncher opened. Select Last Horizon Rebirth (NeoForge 21.1.259) and press Enter the Game.'
    } catch { $ActionStatus.Text=$_.Exception.Message; [System.Windows.MessageBox]::Show($_.Exception.Message,$AppName,'OK','Information')|Out-Null }
})
$DiscordButton.Add_Click({ Start-Process $DiscordUrl })
$CheckUpdatesButton.Add_Click({ try { Invoke-CloudUpdateCheck $false } catch { [System.Windows.MessageBox]::Show($_.Exception.Message,$AppName,'OK','Warning')|Out-Null } })
$UpdatesButton.Add_Click({ try { Invoke-CloudUpdateCheck $false } catch { [System.Windows.MessageBox]::Show($_.Exception.Message,$AppName,'OK','Warning')|Out-Null } })
$ShadersButton.Add_Click({ $SettingsExpander.IsExpanded=$true })
$SettingsToggleButton.Add_Click({ $SettingsExpander.IsExpanded=!$SettingsExpander.IsExpanded })
$HelpButton.Add_Click({ [System.Windows.MessageBox]::Show("Microsoft: install once, add your Microsoft account, then use Play Minecraft.`n`nTLauncher authentication still occurs inside TLauncher.`n`nUpdates are checked automatically and player settings are preserved.",$AppName,'OK','Information')|Out-Null })
$PlayButton.Add_Click({
    try {
        $script:SelectedMode = 'Microsoft'
        $Settings.ramGb = [int]$RamSlider.Value
        $Settings.preset = [string]$PresetBox.SelectedItem
        $Settings.gameDir = $GameDir
        Save-Settings $Settings
        Invoke-CloudUpdateCheck $true
        $ActionStatus.Text = 'Starting Minecraft 1.21.1 with NeoForge to the main menu...'
        Start-DirectGame
    } catch {
        $ActionStatus.Text = $_.Exception.Message
        [System.Windows.MessageBox]::Show($_.Exception.Message, $AppName, 'OK', 'Information') | Out-Null
    }
})
$Window.Add_Closing({
    Save-CurrentModeSettings
    $Settings.ramGb = [int]$RamSlider.Value
    $Settings.shader = [string]$ShaderBox.SelectedItem
    $Settings.preset = [string]$PresetBox.SelectedItem
    $Settings.gameDir = $GameDir
    Save-Settings $Settings
})

$Window.Add_ContentRendered({
    try {
        $parts = $ServerAddress.Split(':')
        $tcp = New-Object Net.Sockets.TcpClient
        $async = $tcp.BeginConnect($parts[0], [int]$parts[1], $null, $null)
        if ($async.AsyncWaitHandle.WaitOne(1800) -and $tcp.Connected) {
            $tcp.EndConnect($async); $ServerStatus.Text = 'Server online'; $ServerDot.Fill = '#58C47D'
        } else { $ServerStatus.Text = 'Server not responding'; $ServerDot.Fill = '#CF5A4B' }
        $tcp.Close()
    } catch { $ServerStatus.Text = 'Status unavailable'; $ServerDot.Fill = '#D8A03E' }
    try { Invoke-CloudUpdateCheck $true } catch { $CloudStatus.Text=$_.Exception.Message; $CloudStatusDot.Fill='#CF5A4B' }
})

Set-SettingsTarget ([string]$SettingsTargetBox.SelectedItem)
$Window.ShowDialog() | Out-Null
