LAST HORIZON: REBIRTH - LAUNCHER V2.0

INSTALL
1. Double-click LastHorizonSetup.exe. No manual extraction is required.
2. Choose Minecraft Account or TLauncher on the opening screen. The two paths use separate game folders.
3. For Microsoft play, use MICROSOFT SETUP / REPAIR > INSTALL / REPAIR GAME, then sign in once with MICROSOFT ACCOUNT / SIGN IN.
4. Press PLAY MINECRAFT. The game opens at its custom Minecraft main menu.
5. Choose ENTER THE HORIZON in Minecraft when you are ready to join the server.

TLAUNCHER TEST PATH
1. Choose TLauncher on the opening screen. Close TLauncher before installing the pack.
2. Press VERIFY / REPAIR PACK. Select the TLauncher executable if asked.
3. The launcher copies the supplied TLauncher pack profile into versions/Last Horizon Rebirth, then installs its mods and configuration into that isolated pack folder.
4. Select Last Horizon Rebirth in TLauncher and press Enter the Game.
5. If the named pack launches, the game opens at its custom Minecraft main menu. Select ENTER THE HORIZON there to join.
6. If TLauncher uses a custom folder, use TLAUNCHER SETUP > CHANGE TLAUNCHER GAME FOLDER first.

TLauncher compatibility opens TLauncher; it does not bypass its authentication or press Play on the player's behalf.
Repair only manages versions/Last Horizon Rebirth. Extra JARs inside that isolated profile are moved to a recoverable repair-backups folder; other TLauncher versions are not changed.
Fresh Reinstall replaces only the selected Last Horizon game profile after moving the old profile to a dated recoverable backup. It does not remove unrelated Minecraft or TLauncher versions.
Running the setup EXE also replaces stale launcher application files automatically, so older launcher builds do not need to be uninstalled manually.
Both Microsoft and TLauncher profiles are pinned to NeoForge 21.1.259. Fresh Reinstall now installs and verifies that exact TLauncher loader before opening TLauncher. NeoForge 21.1.262 and newer currently break the owo-lib networking used by Accessories and can cause clientbound custom_payload disconnects.
The mod pack is included with this installer, so players do not need to download the mods separately. TLauncher itself must be installed separately. The supplied backup contains profile metadata but no game runtime or libraries; TLauncher must be able to download those on first launch. Manual profile discovery from the copied metadata has not yet been tested on Windows.

The Microsoft sign-in is required only once. Later Microsoft launches go from the Last Horizon desktop launcher to the Minecraft main menu.

SETTINGS AND CLOUD UPDATES
- Normal Play no longer performs a full pack repair on every launch.
- Existing options, keybinds, servers, voice settings, maps, resource packs, shader packs, screenshots and saves are preserved.
- Microsoft and TLauncher use separate isolated Last Horizon folders so unrelated old mods cannot leak into the server pack.
- The launcher checks the public GitHub channel at startup and before Play.
- Update bundles and managed files must pass SHA-256 verification before installation.
- Replaced managed files are backed up automatically.

SHADERS
- Choices: Disabled, Photon, Fantasy, Eclipse, Solas, IterationT, Emanrux, Amethyst, Hysteria.
- Photon is included. Other supported shaders download from their official project when selected.
- IterationT must be downloaded manually from its author's page because there is no safe stable automatic download.
- Iris is installed automatically during TLauncher install or repair. Disabled remains the default and turns shaders off without removing Iris.
- Shader selection and graphics presets are applied to the selected Microsoft or TLauncher profile, not to a different shared folder.
- If an optional shader fails to install, the game continues without shaders instead of blocking Play.
- Presets: Best Performance, Balanced, Quality, Cinematic.

IMPORTANT
- This package is for Minecraft Java 1.21.1 + NeoForge.
- Microsoft play uses a separate controlled game folder. TLauncher compatibility uses TLauncher's configured game folder.
- Sign-in is handled by Microsoft's own sign-in page through the managed open-source launch engine.
- This app never requests or stores Microsoft passwords.
- A legitimate Microsoft account that owns Minecraft Java Edition is required for direct play. Authentication bypasses are not included.
- The centered FancyMenu layout is included in the client pack.
- The custom title screen is enabled by default and its activation files are repaired on each launch.
- The startup video intro is deliberately disabled for this beta to keep startup smooth.

SERVER
81.16.177.251:25582

DISCORD
https://discord.gg/47YjgDGfjg
